pip3 install getkey
pip3 install pyPS4Controller
